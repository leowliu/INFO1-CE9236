//
//  ViewController.h
//  Last
//
//  Created by BENJAMIN LIU on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVAudioPlayer.h>
#import <AudioToolbox/AudioToolbox.h>	//needed for SystemSoundID

@interface ViewController : UIViewController <AVAudioPlayerDelegate> {
    UIButton *audioButton;
    UIButton *videoButton;
    UISwitch *mySwitch;
    MPMoviePlayerController *controller;
    SystemSoundID sid;
    AVAudioPlayer *player;
}

@property (nonatomic, retain) IBOutlet UIButton *audioButton;
@property (nonatomic, retain) IBOutlet UIButton *videoButton;
@property (nonatomic, retain) IBOutlet UISwitch *mySwitch;
@property (nonatomic, retain) IBOutlet UIWindow *window;

- (void) valueChanged: (id) sender;

- (void) touchUpInside: (id) sender;

- (void) touchUpInside_1: (id) sender;

@end
