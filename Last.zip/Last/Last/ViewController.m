//
//  ViewController.m
//  Last
//
//  Created by BENJAMIN LIU on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize window = _window;
@synthesize audioButton; 
@synthesize videoButton; 
@synthesize mySwitch; 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSBundle *bundle = [NSBundle mainBundle];
    NSLog(@"bundle.bundlePath == \"%@\"", bundle.bundlePath);	
    
    NSString *filename = [bundle
                          pathForResource: @"chinese"
                          ofType: @"mp3"
                          ];
    NSLog(@"filename == \"%@\"", filename);
    
    NSURL *url = [NSURL fileURLWithPath: filename isDirectory: NO];
    NSLog(@"url == \"%@\"", url);
    
    OSStatus error =
    AudioServicesCreateSystemSoundID((CFURLRef)url, &sid);
    
    if (error != kAudioServicesNoError) {
        NSLog(@"AudioServicesCreateSystemSoundID error == %ld", error);
    }
    
    filename =
    [bundle pathForResource: @"musette" ofType: @"mp3"];
    NSLog(@"filename == \"%@\"", filename);
    
    url = [NSURL fileURLWithPath: filename isDirectory: NO];
    NSLog(@"url == \"%@\"", url);
    
    NSError *error1 = nil;
    player =
    [[AVAudioPlayer alloc] initWithContentsOfURL: url error: &error1];
    
    if (player == nil) {
        NSLog(@"could not initialize player:  %@", error1);
        [error1 release];
    } else {
        player.volume = 1.0;		//the default
        player.numberOfLoops = -1;	//negative for infinite loop
        [player setDelegate: self];
        //mono or stereo
        NSLog(@"number of channels == %u", player.numberOfChannels);
        
        if (![player prepareToPlay]) {
            NSLog(@"could not prepare to play");
        }
    }
    
    filename =
    [bundle pathForResource: @"sneeze" ofType: @"m4v"];
    if (filename == nil) {
        NSLog(@"could not find file sneeze.m4v");
        return;
    }
    NSLog(@"filename == \"%@\"", filename);

    url = [NSURL fileURLWithPath: filename];
    if (url == nil) {
        NSLog(@"could not create URL for file %@", filename);
        return;
    }
    
    controller =
    [[MPMoviePlayerController alloc] init];
    
    if (controller == nil) {
        NSLog(@"could not create MPMoviePlayerController");
        return;
    }

    [controller setContentURL: url];
    controller.scalingMode =  MPMovieScalingModeNone;
    controller.controlStyle = MPMovieControlStyleFullscreen;
    controller.movieSourceType = MPMovieSourceTypeFile; //vs.stream
    [controller retain];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    
    [center
     addObserver: self
     selector: @selector(playbackDidFinish:)
     name: MPMoviePlayerPlaybackDidFinishNotification
     object: controller
     ];
        
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction) valueChanged: (id) sender {
	UISwitch *s = sender;
	if (s.isOn) {
		//The switch has just been turned on.
		if (![player play]) {
			NSLog(@"[player play] failed.");
		}
	} else {
		//The switch has just been turned off.
		[player pause];
		NSLog(@"Paused at %g seconds.", player.currentTime);
	}
}

#pragma mark -
#pragma mark Actions

- (IBAction) touchUpInside: (id) sender {
	
	//The sender is the button that was pressed.
	NSLog(@"The \"%@\" button was pressed.",
          [sender titleForState: UIControlStateNormal]);
	
	//AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
	AudioServicesPlaySystemSound(sid);
}

- (IBAction) touchUpInside_1: (id) sender {
	
	//The sender is the button that was pressed.
	NSLog(@"The \"%@\" video button was pressed.",
          [sender titleForState: UIControlStateNormal]);
	
	//AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
	controller.view.frame = self.view.frame;
    [controller.view setFrame: self.view.bounds];
    [self.view addSubview: controller.view];
    [self.view bringSubviewToFront: controller.view];
	[controller play];
}

- (IBAction) playbackDidFinish: (NSNotification *) notification {
	//notification.object is the controller.
	[controller.view removeFromSuperview];
	[UIApplication sharedApplication].statusBarHidden = NO;
}

- (void)dealloc
{
    [player release];
    [controller release];
    [mySwitch release];
    [super dealloc];
}

@end
