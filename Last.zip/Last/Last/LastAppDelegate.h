//
//  LastAppDelegate.h
//  Last
//
//  Created by BENJAMIN LIU on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVAudioPlayer.h>
@class ViewController;

@interface LastAppDelegate : NSObject <UIApplicationDelegate, AVAudioPlayerDelegate> {
    ViewController *viewController;
	UIWindow *_window;
}

@property (nonatomic, retain) IBOutlet ViewController *viewController;
@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
