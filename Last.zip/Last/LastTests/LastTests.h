//
//  LastTests.h
//  LastTests
//
//  Created by BENJAMIN LIU on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface LastTests : SenTestCase

@end
