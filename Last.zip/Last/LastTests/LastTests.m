//
//  LastTests.m
//  LastTests
//
//  Created by BENJAMIN LIU on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LastTests.h"

@implementation LastTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in LastTests");
}

@end
